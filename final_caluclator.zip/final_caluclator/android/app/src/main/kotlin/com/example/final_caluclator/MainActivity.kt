package com.example.final_caluclator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
